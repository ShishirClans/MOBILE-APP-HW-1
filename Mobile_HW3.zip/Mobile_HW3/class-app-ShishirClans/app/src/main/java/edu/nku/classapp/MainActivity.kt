package edu.nku.classapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit

class MainActivity : AppCompatActivity() {

    private lateinit var bindin: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)


      //  setContentView(binding.root)

       setContentView(R.layout.activity_main)

        supportFragmentManager.commit {
            //add(binding.fragment_container_view, GOTCharacterListFragment())
            add(R.id.fragment_container_view, GOTCharacterListFragment())
            setReorderingAllowed(true)
        }

    }
}

//NEWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW