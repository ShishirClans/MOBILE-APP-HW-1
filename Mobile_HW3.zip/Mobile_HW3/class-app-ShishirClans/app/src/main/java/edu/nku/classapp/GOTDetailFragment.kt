package edu.nku.classapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.commit
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class GOTCharacterAdapter(private val characters: List<GOTCharacter>) :
    RecyclerView.Adapter<GOTCharacterAdapter.GOTCharacterViewHolder>() {

    class GOTCharacterViewHolder(
        itemView: View,
        private val onCharacterClicked: (position: Int) -> Unit
    ): RecyclerView.ViewHolder(itemView) {

        init {
            itemView.setOnClickListener {
                onCharacterClicked(adapterPosition)
            }
        }

        val characterImage: ImageView = itemView.findViewById(R.id.character_image)
        val characterName: TextView = itemView.findViewById(R.id.character_name)
        val characterAge: TextView = itemView.findViewById(R.id.character_age)
        val characterWeapon: TextView = itemView.findViewById(R.id.character_weapon)
        val characterKingdom: TextView = itemView.findViewById(R.id.character_kingdom)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): GOTCharacterViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(
            R.layout.character_card_view,
            parent,
            false
        )

        return GOTCharacterViewHolder(view) { position ->
            val character = characters[position]

            val bundle = bundleOf(
                "name" to character.name,
                "age" to character.age,
                "kingdom" to character.kingdom,
                "weapon" to character.weapon,
                "picture" to character.picture
            )

            val detailFragment = GOTDetailFragment()
            detailFragment.arguments = bundle

            val activity = view.context as AppCompatActivity
            activity.supportFragmentManager.commit {
                setReorderingAllowed(true)
                replace(R.id.fragment_container_view, detailFragment)
                addToBackStack(null)
            }
        }
    }

    override fun getItemCount() = characters.size

    override fun onBindViewHolder(
        holder: GOTCharacterViewHolder,
        position: Int
    ) {
        val character = characters[position]
        holder.characterName.text = holder.itemView.context.getString(R.string.name, character.name)
        holder.characterAge.text = holder.itemView.context.getString(R.string.age, character.age)
        holder.characterWeapon.text = "Weapon: ${character.weapon}"
        holder.characterKingdom.text = "Kingdom: ${character.kingdom}"

        Glide.with(holder.itemView.context)
            .load(character.picture)
            .placeholder(R.drawable.ic_launcher_background)
            .into(holder.characterImage)
    }
}
