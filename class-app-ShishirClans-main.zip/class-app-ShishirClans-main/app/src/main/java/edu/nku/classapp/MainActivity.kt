package edu.nku.classapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private val names = listOf("Ned", "Joffrey", "Cersi", "Jon", "Aegon")
    private val lastNames = listOf("Stark", "Baratheon", "Lannister", "Targaryen")
    private val planets = listOf("Earth", "Mars", "Jupiter", "Saturn", "Neptune")
    private val kingdoms =
        listOf("Casterly Rock", "The North", "The Iron Islands", "Riverrun", "Sunspear")
    private val weapons = listOf("Sword", "Dragon", "Armor", "Canon", "Nuke")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val characters = mutableListOf<GOTCharacter>()


        for (i in 0..30) {
            characters.add(createCharacter(i))
        }

        val recyclerView: RecyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = GOTCharacterAdapter(characters)
    }

    private fun createCharacter(id: Int) = GOTCharacter(
        age = Random.nextInt(1, 80),
        id = id,
        name = names.random() + " " + lastNames.random(),
        planet = planets.random(),
        kingdom = kingdoms.random(),
        picture = R.drawable.ic_launcher_background,
        weapon = weapons.random(),
    )
}

