package edu.nku.classapp

data class GOTCharacter(
    val age: Int,
    val id: Int,
    val name: String,
    val planet: String,
    val picture: Int,
    //
    val weapon: String,
    val kingdom: String,
)
