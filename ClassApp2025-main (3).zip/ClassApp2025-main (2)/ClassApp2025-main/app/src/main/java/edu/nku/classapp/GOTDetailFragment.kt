package edu.nku.classapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class GOTDetailFragment : Fragment() {
/*
    private var _binding: FragmentCharacterDetailBinding? = null
    private var binding
        get() = binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //binding = FragmentCharacterDetailBinding.inflate(inflater,container, false)
        val view = inflater.inflate(R.layout.fragment_character_detail, container, false)

        if (arguments != null) {

           // binding.characterNameDetail.text = requireArguments().getString("name")
            val name = requireArguments().getString("name")
           view.findViewById<TextView>(R.id.character_name_detail).text = name
        }

       // return binding,root
        return view
    }
}  */


 override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_character_detail, container, false)

        val characterImage = view.findViewById<ImageView>(R.id.character_image_detail)
        val characterName = view.findViewById<TextView>(R.id.character_name_detail)
        val characterAge = view.findViewById<TextView>(R.id.character_age_detail)
        val characterPlace = view.findViewById<TextView>(R.id.character_place_detail)
        val characterPower = view.findViewById<TextView>(R.id.character_power_detail)

        arguments?.let {
            characterName.text = it.getString("name")
            characterAge.text = "Age: ${it.getInt("age")}" // Ensure correct age format
            characterPlace.text = "Kingdom: ${it.getString("kingdom")}" // Fix label
            characterPower.text = "Weapon: ${it.getString("weapon")}" // Fix label

            // Load image with Glide
            Glide.with(this)
                .load(it.getString("picture"))
                .placeholder(R.drawable.ic_launcher_background)
                .into(characterImage)
        }
        return view
    }
}


