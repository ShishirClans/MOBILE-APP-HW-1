package edu.nku.classapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HildAndroidApp

class GOTApplication : Application()