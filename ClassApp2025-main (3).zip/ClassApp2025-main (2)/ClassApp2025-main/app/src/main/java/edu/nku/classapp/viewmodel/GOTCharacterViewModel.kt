package edu.nku.classapp.viewmodel

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class GOTCharacterViewModel @Inject constructor() : ViewModel() {

    private val characters = mutableListOf<GOTCharacer>()




    fun fillData() = characters.toList()

    private fun createCharacter(id: Int) = GOTCharacter(
        age = Random.nextInt(1, 100),
        id = id,
        name = names.random() + " " + lastNames.random(),
        planet = planets.random(),
        //picture = "https://GOTapi.com/api/character/avatar/${Random.nextInt(1, 100)}.jpeg"
        picture = "https://thronesapi.com/assets/images/daenerys.jpg"
    )
        )
    }

}